/*  Hier komt de Javascript Code van de Game
    In de klas bouwen we klassikaal de startup code
    Aan jou de taak om de game verder uit te bouwen met:
    - bij elke crash moet de auto een andere afbeelding inladen waarin hij meer beschadigd is 
    (sla zelf nieuwe plaatjes op van de auto waarin je deze bewerkt)
    - De crash-score moet in beeld komen te staan

    Verdieping:
    Plaats een 2e auto, en bestuur deze met de W, S, A, D toetsen van je toetsenbord
    Als de 2 autos tegen elkaar rijden volgt er een explosie
*/
