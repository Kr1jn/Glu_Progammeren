var eersteVariabele = "test";
console.log(eersteVariabele);

var tweedeVariabele = "gay";
console.log(tweedeVariabele);


